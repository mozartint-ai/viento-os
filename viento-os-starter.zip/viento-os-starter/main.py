from fastapi import FastAPI
app=FastAPI(title='Viento OS')

@app.get('/health')
def health():
    return {'status':'ok'}
